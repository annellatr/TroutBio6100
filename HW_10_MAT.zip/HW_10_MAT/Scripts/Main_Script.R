# Homework 9: Strategic Coding Practices
# 02 April 2024
# MAT

# Setup ----
# Load libraries
library(pracma)
library(pryr)
library(devtools)
library(upscaler)
library(tidyverse)
library(ggplot2)

# Create folders
 # add_folder()

# Set up log
set_up_log(my_logfile = 'logfile.txt',
           user_seed=NULL,
           console_echo=FALSE,
           overwrite_log=TRUE)

# Generate functions
# # build_function(c("clean_data",
#                  "extract_year",
#                  "calculate_abundance",
#                  "calculate_S",
#                  "run_regression",
#                  "generate_histo"))


# Gather file names ----
## Save the path to the folder
parent_dir <- "CleanedData/NEON_count-landbird"

## Set up a list to put filenames into
count_files <- list()

## Get the list of folders within the main folder
year_folders <- list.dirs(parent_dir, recursive = FALSE)


# Loop through each year folder
for (i in year_folders) {
  # Find files that contain "countdata" in their name
  file_names <- list.files(i, pattern = "countdata", full.names = TRUE)

  # Check only one file is picked per folder
  if (length(file_names) > 0) {
    count_files[[basename(i)]] <- file_names[1]  # Pick the first valid file
  }
}

l("File names gathered")

# Create initial data frame ----
df <- data.frame(rep(NA,10),rep(NA,10),rep(NA,10),rep(NA,10))
colnames(df) <- c("year","file_name","abundance","species_richness")
# add file names
df[,2] <- file_names
l("Initial data frame created")

# Clean data ----
source("Functions/CleanData.R")
for (i in count_files){
  clean_data(i)
}
l("Data cleaned")

# Extract years ----
source("Functions/ExtractYear.R")
extract_year(count_files)
years <- readRDS(file="DataObjects/year_data.rds")
# add years to data frame
df[,1] <- years
l("Years extracted")

# Calculate abundance for each year ----
source("Functions/CalculateAbundance.R")
abundance_data <- calculate_abundance(x=count_files)
# add abundance to data frame
abundance_vec = unlist(abundance_data, use.names = FALSE)
df[,3] <- abundance_vec
l("Abundance calculated")

# Calculate species richness for each year ----
source("Functions/CalculateS.R")
s_data <- calculate_S(x=count_files)
# add species richness to data frame
s_vec = unlist(s_data, use.names = FALSE)
df[,4] <- s_vec
l("Species richness calculated")

# Run regression of richness vs. abundance ----
source("Functions/RunRegression.R")
reg_data <- as.data.frame(run_regression(S=df$species_richness,A=df$abundance))
l("Regression run")

# Generate histograms for richness and abundance ----
source("Functions/GenerateHisto.R")
generate_histo(data=df, x=df$abundance, n="abundance")
a_histo <- readRDS(file="Plots/abundance_histo.rds")
a_histo

generate_histo(data=df, x=df$species_richness, n="Species_Richness")
s_histo <- readRDS(file="Plots/Species_Richness_histo.rds")
s_histo

l("Histograms generated")
data_table_template(data_frame=df,file_name="Outputs/summary_table.csv")

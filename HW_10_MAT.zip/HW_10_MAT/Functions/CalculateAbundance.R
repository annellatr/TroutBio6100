# --------------------------------------
# FUNCTION calculate_abundance
# required packages: none
# description:
# inputs:
# outputs:
########################################
calculate_abundance <- function(x=NULL){

  # assign parameter defaults
  if (is.null(x)) {
    stop("Please specify a list of files")
  }

  # function body

  # Create a list to store abundance values
  Abundance <- list()

  # Loop through each file and calculate abundance
  for (i in x) {
    data <- read.csv(i)
    Abundance[[i]] <- nrow(data)
  }

  saveRDS(Abundance, file="DataObjects/abundance_data.rds")

  return(Abundance)

}
# end of function calculate_abundance
# --------------------------------------
# calculate_abundance()

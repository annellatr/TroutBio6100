# --------------------------------------
# FUNCTION extract_year
# required packages: none
# description: extracts years from file names
# inputs: list of file names
# outputs: list of years
########################################
extract_year <- function(x=NULL){

# assign parameter defaults
if (is.null(x)) {
  return("Please enter valid file names")
}

# function body

  # extract years
years <- str_extract(x, pattern = "20\\d{2}")

saveRDS(years, file = "DataObjects/year_data.rds")

print("Years saved as an RDS file")

} # end of function extract_year
# --------------------------------------
# extract_year()
